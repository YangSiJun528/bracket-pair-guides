package com.sijunyang.bracketpairguides.benchmarks

import com.sijunyang.bracketpairguides.analysis.*
import com.sijunyang.bracketpairguides.analysis.snapshot.*
import java.util.concurrent.CancellationException
import kotlinx.coroutines.runBlocking

/** Same synthetic input and result work as the candidate; old pure orchestration is benchmark-owned. */
class CalculationWorkload(pairCount: Int, distribution: String) {
    private val text = when (distribution) {
        "nested" -> "{".repeat(pairCount) + "\n  value\n" + "}".repeat(pairCount)
        "sparse" -> "{\n" + "  ordinary text without brackets\n".repeat(pairCount) + "}\n"
        "malformed" -> "{]\n".repeat(pairCount)
        else -> "{\n  value\n}\n".repeat(pairCount)
    }
    private val input = BaselineInput(text)
    private val coverage = AnalysisCoverage(true, true, true)
    private val fileType = Any()
    private val stamp = AnalysisStamp(0, fileType, coverage, emptySet(), 4, Any())
    private val calculator = BaselineEngine(input, stamp, fileType)
    private val ready = runBlocking { calculator.analyze {} }
    fun analyzeCold(): AnalysisOutcome = runBlocking { BaselineEngine(input, stamp, fileType).analyze {} }
    fun analyzeReuse(): AnalysisOutcome = runBlocking { calculator.analyze {} }
    fun query(): Int {
        val snapshot = snapshot(ready) ?: return -1
        val window = snapshot.visibleTokens(0, minOf(text.length, 1024), 1, 2048)
        var checksum = window.size
        for (index in 0 until window.size) checksum = checksum xor window.offsetAt(index) xor window.depthAt(index)
        return checksum
    }
    fun repair(): Any? = runBlocking {
        val pair = snapshot(ready)?.activePairAt(1) ?: return@runBlocking null
        calculator.repair(pair) {}
    }
    fun cancel(): Boolean {
        var checkpoints = 0
        return try {
            runBlocking { BaselineEngine(input, stamp, fileType).analyze { if (++checkpoints == 8) throw CancellationException() } }
            false
        } catch (_: CancellationException) { true }
    }
    /** Non-measured compatibility evidence; never called by a JMH benchmark method. */
    fun semanticFingerprint(): String {
        fun digest(value: String): String = java.security.MessageDigest.getInstance("SHA-256")
            .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it.toInt() and 255) }
        val snapshot = snapshot(ready)
        val limit = when (ready) {
            is AnalysisOutcome.Limited -> ready.limit
            is AnalysisOutcome.Unavailable -> ready.limit
            is AnalysisOutcome.Complete -> null
        }
        return buildString {
            appendLine("text=${digest(text)}")
            appendLine("length=${text.length}")
            appendLine("lines=${input.lineCount}")
            appendLine("state=${if (snapshot == null) "unavailable" else "available"}")
            appendLine("coverage=${snapshot?.stamp?.coverage ?: ready.stamp.coverage}")
            appendLine("matcher=${snapshot?.matcherAvailability?.name ?: "UNDETERMINED"}")
            appendLine("limit=$limit")
            if (snapshot != null) {
                val all = snapshot.visibleTokens(0, text.length, 1, Int.MAX_VALUE)
                val contents = buildString {
                    for (index in 0 until all.size) append("${all.offsetAt(index)},${all.lengthAt(index)},${all.depthAt(index)};")
                }
                appendLine("tokens=${all.size}:${all.isCapped}:${digest(contents)}")
                val offsets = listOf(0, 1, text.length / 4, text.length / 2, 3 * text.length / 4, text.length - 1, text.length)
                    .map { it.coerceIn(0, text.length) }.distinct().sorted()
                for (offset in offsets) {
                    val pair = snapshot.activePairAt(offset)
                    appendLine("sample=$offset:$pair:${pair?.let(snapshot::guideFor)}")
                }
            }
            appendLine("repair=${repair()}")
            appendLine("query=${query()}")
            appendLine("cancel=${cancel()}")
        }
    }
    private fun snapshot(outcome: AnalysisOutcome): BracketSnapshot? = when (outcome) {
        is AnalysisOutcome.Complete -> outcome.snapshot
        is AnalysisOutcome.Limited -> outcome.snapshot
        is AnalysisOutcome.Unavailable -> null
    }
}
