package com.sijunyang.bracketpairguides.benchmarks

import com.sijunyang.bracketpairguides.analysis.*
import com.sijunyang.bracketpairguides.analysis.guide.*
import com.sijunyang.bracketpairguides.analysis.pairing.*
import com.sijunyang.bracketpairguides.analysis.pairing.core.*
import com.sijunyang.bracketpairguides.analysis.snapshot.*
import java.util.LinkedHashMap

/** SDK-free stages of IncrementalAnalysis, GuideRepairExecution and stampedOutcome at 072533f. */
internal class BaselineEngine(private val input: BaselineInput, private val stamp: AnalysisStamp, private val fileType: Any) {
    private val indexes = BaselineCanonicalIndexes()
    suspend fun analyze(checkCanceled: () -> Unit): AnalysisOutcome {
        checkCanceled()
        val source = capture(checkCanceled) { Source(input, input.text.length, input.lineCount) }
        val recognition = recognize(source.tokens, checkCanceled)
        checkCanceled()
        val prepared = SnapshotCalculation.prepare(stamp.coverage, recognition, source.length, source.lines, checkCanceled)
        val guides = prepared.guideLines?.let { guidePositions(it, checkCanceled) }
        val calculated = prepared.finish(guides)
        capture(checkCanceled) { Unit }
        return when (calculated) {
            is CalculatedAnalysis.Unavailable -> AnalysisOutcome.Unavailable(stamp, calculated.limit)
            is CalculatedAnalysis.Available -> {
                val derived = stamp.withCoverage(calculated.coverage)
                val canonical = indexes.canonical(input, calculated.layout, derived.coverage,
                    derived.tabSize.takeIf { calculated.indexes.hasGuidePositions }, fileType,
                    derived.disabledLanguageIds, calculated.canonicalPairs, calculated.indexes, checkCanceled)
                val view = canonical.newSnapshot(derived, calculated.matcherAvailability)
                calculated.limit?.let { AnalysisOutcome.Limited(stamp, view, it) } ?: AnalysisOutcome.Complete(view)
            }
        }
    }
    private suspend fun recognize(tokens: BaselineInput, checkCanceled: () -> Unit): DocumentBracketRecognition {
        val pairs = PairCollection(BracketRecognitionLimits.completedPairs)
        val pairing = PairingMachine<TokenKind, BracketGroupId>().newSession(pairs, CancellationProbe(checkCanceled),
            BracketRecognitionLimits.MAXIMUM_PENDING_OPENS)
        val answers = LinkedHashMap<PairingMachine.RuleRequest<TokenKind, BracketGroupId>, Boolean>(16, 0.75f, true)
        var offset = 0
        try {
            while (true) {
                val batch = capture(checkCanceled) { tokens.tokensAt(offset) }
                if (!batch.sourceAvailable) return DocumentBracketRecognition.Complete(PairTable.empty(), BraceMatcherAvailability.UNDETERMINED)
                for (index in 0 until batch.size) {
                    if (index and 255 == 0) checkCanceled()
                    var step = batch.begin(index, pairing)
                    while (step == PairingMachine.Step.NEEDS_RULE) {
                        val request = pairing.ruleRequest()
                        val answer = answers[request] ?: capture(checkCanceled) { tokens.areCompatible(request.openToken(), request.closeToken()) }.also {
                            answers[request] = it
                            if (answers.size > 2048) { val oldest = answers.entries.iterator(); oldest.next(); oldest.remove() }
                        }
                        step = pairing.resume(answer)
                    }
                    if (step == PairingMachine.Step.PENDING_CAPACITY) return DocumentBracketRecognition.Unavailable(BracketRecognitionRefusal.PENDING_OPEN_CAPACITY)
                }
                if (batch.end) return DocumentBracketRecognition.Complete(checkNotNull(pairs.authoritativePairs()), batch.matcherAvailability)
                offset = batch.nextOffset
            }
        } catch (_: PairCapacityReached) { return DocumentBracketRecognition.Unavailable(BracketRecognitionRefusal.PAIR_CAPACITY) }
    }
    private class Source(val tokens: BaselineInput, val length: Int, val lines: Int)

    private suspend fun guidePositions(lines: IntRange, checkCanceled: () -> Unit): GuidePositionIndex {
        val builder = checkNotNull(GuidePositionIndex.builder(lines.first, lines.last - lines.first + 1, checkCanceled))
        var firstLine = lines.first
        while (firstLine <= lines.last) {
            val afterLine = minOf(firstLine.toLong() + 128, lines.last.toLong() + 1).toInt()
            val prefixes = capture(checkCanceled) { (firstLine until afterLine).map { input.prefix(it, input.start(it), 128) } }
            for ((relative, prefix) in prefixes.withIndex()) {
                val indentation = LineIndentation(4, checkCanceled)
                var current = prefix
                indentation.append(current.text, current.after == current.end)
                while (!indentation.isComplete) {
                    current = capture(checkCanceled) { input.prefix(firstLine + relative, current.after, 4096) }
                    indentation.append(current.text, current.after == current.end)
                }
                builder.append(indentation.column)
            }
            firstLine = afterLine
        }
        return builder.seal()
    }
    suspend fun repair(pair: BracketPair, checkCanceled: () -> Unit): BracketGuide? {
        val lines = capture(checkCanceled) {
            val last = input.lineCount - 1
            val first = (if (pair.openLine < pair.closeLine) pair.openLine + 1 else pair.closeLine).coerceIn(0, last)
            first..pair.closeLine.coerceIn(first, last)
        }
        val calculation = GuideRepairCalculation(pair, lines, 4, true, null, checkCanceled)
        while (true) {
            val line = calculation.nextLine() ?: break
            var prefix = capture(checkCanceled) { input.prefix(line, input.start(line), 128) }
            while (!calculation.append(prefix.text, prefix.after == prefix.end)) prefix = capture(checkCanceled) { input.prefix(line, prefix.after, 4096) }
        }
        val guide = calculation.result()
        capture(checkCanceled) { Unit }
        return guide
    }
    private suspend fun <T> capture(checkCanceled: () -> Unit, action: () -> T): T {
        checkCanceled()
        val result = action()
        checkCanceled()
        return result
    }
}
