package com.sijunyang.bracketpairguides.benchmarks

import com.sijunyang.bracketpairguides.analysis.AnalysisCoverage
import com.sijunyang.bracketpairguides.analysis.pairing.core.CancellationProbe
import com.sijunyang.bracketpairguides.analysis.pairing.core.PairTable
import com.sijunyang.bracketpairguides.analysis.snapshot.BracketIndexes
import com.sijunyang.bracketpairguides.analysis.snapshot.IndexLayout
import java.lang.ref.WeakReference
import java.util.WeakHashMap
import java.util.concurrent.locks.LockSupport
import java.util.concurrent.locks.ReentrantLock

/** SDK-free port of baseline DocumentBracketIndexes; input/fileType stand in for fixed host identities. */
internal class BaselineCanonicalIndexes {
    private val generations = WeakHashMap<Any, Generation>()
    fun canonical(document: Any, layout: IndexLayout, coverage: AnalysisCoverage, tabSize: Int?,
        fileType: Any, disabled: Set<String>, pairs: PairTable, candidate: BracketIndexes,
        checkCanceled: () -> Unit): BracketIndexes {
        checkCanceled()
        val generation = synchronized(generations) {
            generations[document]?.takeIf { it.revision == 0L } ?: Generation(0).also { generations[document] = it }
        }
        return generation.canonical(Identity(layout, coverage, tabSize, fileType, disabled), pairs, candidate, checkCanceled)
    }
    private class Generation(val revision: Long) {
        private val lock = ReentrantLock()
        private val entries = ArrayList<Entry>()
        fun canonical(identity: Identity, pairs: PairTable, candidate: BracketIndexes, checkCanceled: () -> Unit): BracketIndexes {
            while (!lock.tryLock()) { checkCanceled(); LockSupport.parkNanos(250_000L) }
            try {
                checkCanceled()
                val hash = pairs.contentHash()
                val cancellation = CancellationProbe(checkCanceled)
                val iterator = entries.iterator()
                while (iterator.hasNext()) {
                    checkCanceled()
                    val entry = iterator.next()
                    val indexes = entry.indexes.get(); val existingPairs = entry.pairs.get()
                    if (indexes == null || entry.identity.layout.activePair && existingPairs == null) { iterator.remove(); continue }
                    if (!entry.identity.sameAs(identity)) continue
                    val same = if (identity.layout.activePair) entry.hash == hash && checkNotNull(existingPairs).hasSameContent(pairs, cancellation)
                        else indexes.hasSameTokenContent(candidate, checkCanceled)
                    if (same) return indexes
                }
                entries += Entry(identity, hash, WeakReference(pairs), WeakReference(candidate))
                return candidate
            } finally { lock.unlock() }
        }
    }
    private class Identity(val layout: IndexLayout, private val coverage: AnalysisCoverage, private val tabSize: Int?,
        fileType: Any, private val disabled: Set<String>) {
        private val fileType = WeakReference(fileType)
        fun sameAs(other: Identity): Boolean {
            val mine = fileType.get() ?: return false
            val theirs = other.fileType.get() ?: return false
            return layout == other.layout && coverage == other.coverage && tabSize == other.tabSize && mine === theirs && disabled == other.disabled
        }
    }
    private class Entry(val identity: Identity, val hash: Int, val pairs: WeakReference<PairTable>, val indexes: WeakReference<BracketIndexes>)
}
