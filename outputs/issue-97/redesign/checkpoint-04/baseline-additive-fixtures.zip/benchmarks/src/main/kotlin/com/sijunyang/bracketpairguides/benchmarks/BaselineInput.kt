package com.sijunyang.bracketpairguides.benchmarks

import com.sijunyang.bracketpairguides.analysis.BraceMatcherAvailability
import com.sijunyang.bracketpairguides.analysis.pairing.*
import com.sijunyang.bracketpairguides.analysis.pairing.core.BracketRole
import com.sijunyang.bracketpairguides.analysis.pairing.core.StructuralRole

internal class BaselineInput(val text: String) {
    private val starts = buildList { add(0); text.forEachIndexed { index, ch -> if (ch == '\n') add(index + 1) } }
    val lineCount get() = starts.size
    fun start(line: Int) = starts[line]
    private val open = TokenKind()
    private val close = TokenKind()
    private val group = BracketGroupId(0, 0)
    fun areCompatible(open: TokenKind, close: TokenKind) = open === this.open && close === this.close
    fun tokensAt(offset: Int): CapturedBracketTokens {
        val collector = CapturedBracketTokens.Builder(32)
        var cursor = offset; var visited = 0
        while (cursor < text.length && visited < 512) {
            val character = text[cursor]
            if (character == '{' || character == '}') {
                val opening = character == '{'
                val line = starts.binarySearch(cursor).let { if (it >= 0) it else -it - 2 }
                collector.append(if (opening) open else close, group, null, false,
                    if (opening) BracketRole.OPEN else BracketRole.CLOSE,
                    if (opening) StructuralRole.OPEN else StructuralRole.CLOSE, cursor, 1, line)
            }
            cursor++; visited++
        }
        return collector.seal(cursor, cursor == text.length, visited, BraceMatcherAvailability.AVAILABLE)
    }
    fun prefix(line: Int, offset: Int, maximum: Int): BaselinePrefix {
        val end = if (line + 1 < starts.size) starts[line + 1] - 1 else text.length
        val stop = minOf(end, offset + maximum)
        return BaselinePrefix(text.substring(offset, stop), stop, end)
    }
}
internal class BaselinePrefix(val text: String, val after: Int, val end: Int)
