package com.sijunyang.bracketpairguides.comparison

import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.application.EDT
import com.intellij.openapi.application.readAction
import com.intellij.openapi.editor.Editor
import com.intellij.openapi.editor.EditorFactory
import com.intellij.openapi.progress.ProgressManager
import com.intellij.openapi.util.TextRange
import com.sijunyang.bracketpairguides.analysis.AnalysisCoverage
import com.sijunyang.bracketpairguides.analysis.AnalysisInput
import com.sijunyang.bracketpairguides.analysis.BracketPair
import com.sijunyang.bracketpairguides.analysis.intellij.BracketAnalysis
import com.sijunyang.bracketpairguides.analysis.intellij.BracketTokenCapture
import com.sijunyang.bracketpairguides.analysis.snapshot.AnalysisOutcome
import com.sijunyang.bracketpairguides.analysis.snapshot.BracketSnapshot
import com.sijunyang.bracketpairguides.editor.EditorGuideSessions
import com.sijunyang.bracketpairguides.editor.EditorSurfaceClassifier
import com.sijunyang.bracketpairguides.editor.highlighting.EditorAnalysisExecution
import com.sijunyang.bracketpairguides.editor.highlighting.GuideRepairExecution
import com.sijunyang.bracketpairguides.editor.highlighting.NativeGuideConflictDetector
import com.sijunyang.bracketpairguides.editor.policy.EditorActivity
import com.sijunyang.bracketpairguides.presentation.GuideRepairRequest
import com.sijunyang.bracketpairguides.presentation.BracketGuideDrawing
import com.sijunyang.bracketpairguides.presentation.observedBracketMarkup
import com.sijunyang.bracketpairguides.preferences.BracketGuidePreferences
import com.sijunyang.bracketpairguides.settings.BracketGuideSettings
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Fresh SDK measurements of unchanged 072533f production; this is not the JMH orchestration port. */
class BaselineComparisonHost : ComparisonHost {
    override val implementation = "baseline-072533f"
    private val analyzer = BracketAnalysis()

    override fun assertNoUnownedAttachments() {
        ApplicationManager.getApplication().assertIsDispatchThread()
        val attached = EditorFactory.getInstance().allEditors.filter { EditorGuideSessions.get(it) != null }
        check(attached.isEmpty()) {
            "Unexpected baseline editor guide attachments outside owned lifetime: " + attached.joinToString {
                "kind=${it.editorKind},editorIdentity=${System.identityHashCode(it)}," +
                    "documentIdentity=${System.identityHashCode(it.document)},length=${it.document.textLength},disposed=${it.isDisposed}"
            }
        }
    }

    override fun newReads(): ReadRecorder = object : ReadRecorder {
        private val recorder = BaselineReadMeasurements()
        override val context get() = recorder.context
        override val nativePhase get() = recorder.nativePhase
        override fun onNativeProgress(listener: ((String, Int) -> Unit)?) = recorder.onNativeProgress(listener)
        override fun reset() = recorder.reset()
        override fun requests() = recorder.requests().map {
            ReadRequest(it.requestId, it.phase, it.requestedNanos, it.threadId, it.edt, it.readAllowed)
        }
        override fun snapshot() = recorder.snapshot().map {
            ReadSample(it.requestId, it.attemptId, it.phase, it.requestedNanos, it.enteredNanos,
                it.exitedNanos, it.threadId, it.edt, it.readAllowed, it.allocatedBytes,
                it.completed, it.failureClass)
        }
    }

    override suspend fun analyze(editor: Editor, mode: String): AnalysisHandle {
        val input = input(editor, coverage(mode))
        val result = checkNotNull(analyzer.analyzeInBackground(input)) { "Stable fixture source invalidated" }
        return Result(result, editor.document.textLength)
    }

    override suspend fun repair(editor: Editor, result: AnalysisHandle, offset: Int, exact: Boolean): RepairShape? {
        val pair = (result as Result).snapshot?.activePairAt(offset) ?: return null
        val captured = input(editor, GuideRepairRequest.COVERAGE)
        val request = GuideRepairRequest(pair, captured.stamp, captured.fileType, emptySet(), exact,
            result.snapshot?.guideFor(pair)?.anchorLine)
        return GuideRepairExecution.calculateGuide(editor, request)?.let {
            RepairShape(it.pair.shape(), it.guideColumn)
        }
    }

    override suspend fun capture(editor: Editor, mode: String): CaptureHandle {
        val input = input(editor, coverage(mode))
        val adapter = readAction { BracketTokenCapture(input) }
        return object : CaptureHandle {
            private var closed = false
            override val retainedInput: Any get() = adapter
            override suspend fun next(offset: Int): CapturedChunk {
                check(!closed)
                val context = currentCoroutineContext()
                val batch = readAction {
                    adapter.capture(offset, 512) { context.ensureActive(); ProgressManager.checkCanceled() }
                }
                return CapturedChunk(batch, batch.nextOffset, batch.end, batch.size)
            }
            override fun close() { closed = true }
        }
    }

    override fun execution(editor: Editor, mode: String, reads: ReadRecorder, onPublication: () -> Unit): ExecutionHandle {
        check(ApplicationManager.getApplication().isDispatchThread)
        val settings = BracketGuideSettings.getInstance()
        val previous = settings.options
        settings.loadState(BracketGuidePreferences(showActivePairBorder = true))
        val expected = coverage(mode)
        val root = SupervisorJob()
        val scope = CoroutineScope(root + Dispatchers.Default + reads.context)
        val stamp = AtomicReference<AnalysisInput?>()
        val repair = GuideRepairExecution(scope)
        val execution = EditorAnalysisExecution(scope, { input ->
            check(input.coverage == expected) { "Actual surface coverage differs from requested measurement mode" }
            stamp.set(input)
            analyzer.analyzeInBackground(input)
        }, activity = { EditorActivity.ACTIVE },
            visibleRange = { TextRange(0, it.document.textLength) }, stickySourceRanges = { emptyList() },
            repairExecution = { repair })
        return object : ExecutionHandle {
            private var published = false
            private var closed = false
            override fun request() {
                check(ApplicationManager.getApplication().isDispatchThread)
                published = false
                stamp.set(null)
                execution.request(editor)
            }
            override fun markupCount(): Int {
                val count = editor.observedBracketMarkup().allMarks.size
                if (!published && count > 0 && stamp.get()?.let { EditorGuideSessions.canSkipAnalysis(editor, it.stamp) } == true) {
                    published = true
                    onPublication()
                }
                return if (published) count else 0
            }
            override fun refresh() {
                check(ApplicationManager.getApplication().isDispatchThread)
                EditorGuideSessions.get(editor)?.caretMoved()
            }
            override fun markup(): List<Any> = editor.observedBracketMarkup().allMarks
            override fun workerActive() = if (closed) !root.isCompleted else
                root.children.any { owner -> owner.children.any { it.isActive } }
            override fun close() {
                check(ApplicationManager.getApplication().isDispatchThread)
                closed = true
                execution.dispose()
                repair.dispose()
                EditorGuideSessions.dispose(editor)
                root.cancel()
                settings.loadState(previous)
            }
        }
    }

    override fun editSession(editor: Editor, reads: ReadRecorder): EditHandle {
        val owned = execution(editor, "all", reads) { }
        try { owned.request() }
        catch (failure: Throwable) {
            try { owned.close() } catch (cleanup: Throwable) { failure.addSuppressed(cleanup) }
            throw failure
        }
        return object : EditHandle {
            override fun markup() = owned.markup()
            override fun workerActive() = owned.workerActive()
            override fun close() = owned.close()
            override fun visibleGuide(): GuideShape? {
                ApplicationManager.getApplication().assertIsDispatchThread()
                val guides = editor.markupModel.allHighlighters.filter { it.isValid }
                    .mapNotNull { (it.customRenderer as? BracketGuideDrawing)?.guide }
                check(guides.size <= 1) { "Multiple actual guide renderers were retained" }
                val guide = guides.singleOrNull() ?: return null
                return GuideShape(guide.pair.shape(), guide.guideColumn, guide.anchorLine)
            }
        }
    }

    override suspend fun native(editor: Editor, result: AnalysisHandle, pairOffset: Int, caret: Int, showVertical: Boolean): NativeShape {
        val pair = (result as Result).snapshot?.activePairAt(pairOffset) ?: return NativeShape(false, 0, 0)
        val captured = withContext(Dispatchers.EDT) {
            editor.caretModel.moveToOffset(caret)
            NativeGuideConflictDetector.captureMarkerSources(editor, pair, showVertical)
        }
        val context = currentCoroutineContext()
        val sources = captured { context.ensureActive(); ProgressManager.checkCanceled() }
        // This is actual native source resolution. Headless native painting/UI eligibility is not covered.
        return NativeShape(true, if (sources.direct) 1 else 0, if (sources.currentScope) 1 else 0)
    }

    override fun close() = Unit

    private suspend fun input(editor: Editor, coverage: AnalysisCoverage) = withContext(Dispatchers.EDT) {
        AnalysisInput(editor, EditorSurfaceClassifier.fileType(editor), coverage, emptySet())
    }

    private fun coverage(mode: String) = when (mode) {
        "all" -> AnalysisCoverage(true, true, true)
        "tokens" -> AnalysisCoverage(true, false, false)
        else -> error("Unknown SDK comparison mode: $mode")
    }

    private class Result(private val outcome: AnalysisOutcome, private val length: Int) : AnalysisHandle {
        override val payload: Any get() = outcome
        val snapshot: BracketSnapshot? get() = when (outcome) {
            is AnalysisOutcome.Complete -> outcome.snapshot
            is AnalysisOutcome.Limited -> outcome.snapshot
            is AnalysisOutcome.Unavailable -> null
        }
        override fun shape(): ResultShape {
            val snapshot = snapshot
            val tokens = snapshot?.visibleTokens(0, length, 0, Int.MAX_VALUE)
            var checksum = 0L
            if (tokens != null) repeat(tokens.size) {
                checksum = checksum * 31 + tokens.offsetAt(it)
                checksum = checksum * 31 + tokens.lengthAt(it)
                checksum = checksum * 31 + tokens.depthAt(it)
            }
            val coverage = snapshot?.stamp?.coverage ?: outcome.stamp.coverage
            return ResultShape(snapshot != null, when (outcome) {
                is AnalysisOutcome.Complete -> null
                is AnalysisOutcome.Limited -> outcome.limit.name
                is AnalysisOutcome.Unavailable -> outcome.limit.name
            }, "${coverage.tokens}:${coverage.activePair}:${coverage.guidePosition}",
                snapshot?.matcherAvailability?.name ?: "UNDETERMINED", tokens?.size ?: 0, checksum,
                tokens?.isCapped ?: false)
        }
        override fun sample(offset: Int) = snapshot?.activePairAt(offset)?.shape()
    }
}

private fun BracketPair.shape() = PairShape(openOffset, openTokenLength, openLine,
    closeOffset, closeTokenLength, closeLine, depth)
