# Baseline counterfactual Driver adapter

This opt-in diagnostic runs the byte-identical final candidate Driver test/corpus against unchanged baseline production 072533f. All functional assertions and all twelve capture scenarios remain enabled. Capture-only is forcibly enabled; completion means diagnostic contract/capture completion, not a reviewed visual pass. Existing tests/build scripts/images are untouched.

The additive bridge changes only production entrypoint/package connections: settings use the actual baseline BracketGuideSettingsController command, requests use the actual public EditorAnalysisRequests request seam. Focus, SDK daemon readiness, actual markup observations and screenshot acceptance are preserved. No runtime getter, synthetic renderer, native decoration removal or daemon restart is introduced.

The init script creates separate compile outputs for the new bridge and copied Driver. The installed plugin ZIP is the ordinary baseline release ZIP plus one new bridge JAR, built from only the new bridge classes/own Kotlin metadata. The old test/Driver helper output is not packaged. `build/counterfactual-driver/archive-evidence.json` verifies every baseline release entry byte unchanged, exactly one extra bridge JAR, identical embedded bridge bytes, and only EditorContractBridge class names. This verification has not yet executed.

Linux/container invocation (working directory repository root; reuse the same pinned image/cache/Xvfb setup as candidate Driver10):

```sh
unset CI
export VISUAL_TEST_ENVIRONMENT=ideaIC-2024.2.6/linux-x64-xvfb96-darcula-scale1
xvfb-run --auto-servernum --server-args='-screen 0 1920x1080x24 -dpi 96 -nolisten tcp -ac' ./gradlew --no-daemon --no-watch-fs --max-workers=2 --no-configuration-cache -I plugin/counterfactual-driver/counterfactual-driver.init.gradle -Dissue97.driver.counterfactual=true -Dissue97.driver.output=/results/baseline-current-driver :plugin:visualTest --console=plain --stacktrace
```

Compile/archive-only preparation, also requiring an absolute unused diagnostic output root:

```sh
./gradlew --no-daemon --max-workers=1 --no-configuration-cache -I plugin/counterfactual-driver/counterfactual-driver.init.gradle -Dissue97.driver.counterfactual=true -Dissue97.driver.output=/absolute/fresh/baseline-driver-smoke :plugin:compileCounterfactualBridgeKotlin :plugin:compileCounterfactualDriverKotlin :plugin:buildCounterfactualDriverPlugin --console=plain
```

Collect `/results/baseline-current-driver/artifacts`, baseline plugin test-results/reports, `build/counterfactual-driver/archive-evidence.json`, the composed ZIP/bridge JAR/release ZIP and this folder's source-manifest. Driver-selected IDE path must remain exact IC242.26775.15; actual JBR21, image identity, display/font/scale and project readiness evidence must match the candidate. Do not replace source image files or use recordVisualTestBaseline.

Compare the twelve new raw images to candidate Driver10 and separately to the existing oracle. Matching changed pixels on both production sides supports a readiness/oracle timing explanation for those pixels; differing output leaves regression unresolved. Earlier functional assertion failure remains a failure and must not be skipped to obtain later captures.

No compile, archive check, Driver run or visual comparison was executed while preparing this adapter. Source copy hashes are in source-manifest.json.
